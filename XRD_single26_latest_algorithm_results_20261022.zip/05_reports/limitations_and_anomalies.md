# Limitations

No independent crystallographic reviewer is represented. Missing metrics remain missing; trial/snapshot counts are not independent sample counts.
