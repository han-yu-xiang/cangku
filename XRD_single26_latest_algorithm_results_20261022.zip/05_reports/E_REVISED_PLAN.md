# Revised E-scope for the 26-sample latest-algorithm rerun

- S/F/D full refinements: 78 tasks (26 samples x 3 workflows).
- Four-policy offline ranking: all unique CWF snapshots from the new run.
- New Top-1 R00/R11 paired trials: 40 states, 80 nominal trials; per sample: earliest divergent state, plus the latest divergent state only when its stage signature differs.
- Stage-mechanism validation: 18 deterministic early/late pairs across no more than four samples.
- Candidate trial jobs after exact-identity deduplication: 100.
- Top-2/Top-3 real refinements, ordinary two-step trajectories, exhaustive stage pairs, and fixed-state timing benchmark are not run. Their offline rankings and explicit skipped dispositions are retained.
- Previous-run candidate outcomes are not reused as current results because the backend algorithm changed; previous run data remain untouched and are linked through the supersession index.
- Independent scientific labels are INDETERMINATE unless the saved evidence provides a genuinely independent reference; native acceptance alone is not treated as scientific validation.
