# Results

Formal task records: 78; CWF calls: 808; candidate trials: 100. The checkpoint stage is `COMPLETED_WITH_REVISED_E_SCOPE`. Figures rendered from persisted source tables: 3. See the CSV/JSONL evidence for denominators and failures.

Post-start E-stage scope revision: the original V3 E_TRIALS queue was stopped and reclassified; only the frozen KEEP_RUN subset was dispatched in E_TRIALS_REVISED. The full original E-stage candidate enumeration was not completed. See 07_reports/E_REVISED_PLAN.md and E_TASK_DISPOSITION.csv. Original completed, failed, skipped and interrupted records remain distinguishable.
