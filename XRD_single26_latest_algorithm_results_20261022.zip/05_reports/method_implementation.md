# Method

S/F/D use the frozen experiment hooks around the installed Single V2 worker; native refinement gates are not replaced. Four-policy ranking is offline replay on full same-kernel CWF records. Candidate trials use isolated GPX copies and existing native transaction checks. See `00_manifest/preregistered_design.md` for frozen definitions.
