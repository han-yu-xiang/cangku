# Runner resume repair

- Date: 2026-10-22 (Asia/Shanghai)
- Scope: run-local orchestration only; no production refinement or CWF algorithm changed.
- Preserved pre-repair checkpoint, status, failure record, launch receipt, and both runner scripts under `07_reports/runner_repair_archive/before_resume_20261022_092551/`.
- Root cause: `stage_transition_pairs.csv` rows contained `early_instance_id` and `later_instance_id`, but the CSV writer's field list omitted both columns. The subsequent disposition reader therefore raised `KeyError: 'early_instance_id'`.
- Repair: include both instance-ID columns in the stage-pair CSV schema.
- Worker-status reconciliation: all 24 E_FULL rows previously marked `REFINEMENT_FAILED` were checked against their persisted task summary and native result. All 24 passed: summary status/job/sample matched, result existed, snapshot hash matched the frozen job, and record counts matched. Resume will mark the durable Native results `COMPLETED` in the checkpoint while preserving each original failed task record and worker-exit error as audit evidence.
- Validation before resume: project `.venv` `py_compile` passed for the repaired `run_v3_pipeline.py`; 24/24 durable E_FULL results passed integrity checks.
- Recovery rule: completed S/F/D and E_FULL outputs are reused; no completed refinement or valid native CWF result is intentionally rerun.

## Finalization resume

- The prior coordinator had no live PID; all 78 formal tasks and all 275 revised E-trial jobs were terminal (259 completed, 16 failed), with zero active workers. The finalization status was stale and the package/reconciliation was incomplete.
- A resume attempt began rebuilding the already-frozen E_FULL index from the 1+ GB formal CWF-call logs. It launched no refinement workers and wrote no scientific results; it was stopped after its memory use exceeded 5 GB.
- Run-local resume improvement: reuse terminal E_FULL job records instead of rescanning formal CWF logs. The finalizer now streams decision-trace JSONL and retains only `call_id -> N_final_raw`, rather than materializing the full trace file in memory.
- No completed task or candidate was rerun; all existing raw task artifacts and failures remain unchanged.
