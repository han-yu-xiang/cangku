# Reproducibility

Use the project `.venv`, locked inputs and run scripts in `06_scripts/`. One RefinementScheduler owns all outer jobs with six slots; CWF worker count is two and GSAS-II internal multiprocessing is zero.
