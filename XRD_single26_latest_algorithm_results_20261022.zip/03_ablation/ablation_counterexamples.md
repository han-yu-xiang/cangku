# Counterexamples

No independently reviewed classification is invented here. All native trial results, including failures, remain in the trial ledger.
