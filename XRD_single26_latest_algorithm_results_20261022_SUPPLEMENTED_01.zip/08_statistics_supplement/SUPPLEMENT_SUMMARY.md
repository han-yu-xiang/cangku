# Single26 三项统计补充

数据来源：`single26_cwf_latest_algorithm_20261022_000834_bfb57dfd` 的正式 S/F/D 任务摘要、各任务 `runtime_profile.json`、Top-1 候选 trial JSON；候选调度差异取自原包 `03_ablation/candidate_task_status_reconciliation.csv`。未运行精修，未修改原实验文件。原包 SHA-256：`8be48dcf94bed34f724fbac95eb859ca3dc8b87f72402964a0b451ea13237212`。

## 1. 78 次完整精修总耗时

`runtime_seconds_worker_total` 采用每任务 `runtime_profile.json` 的 `worker_total_wall_seconds`（Worker 实际运行墙钟，含进程启动、引擎和产物落盘；不含排队等待）。队列等待另列。这里的总和是 78 个任务运行时间的加总，不等于 6 路并行批次的实际日历墙钟时长。

| 组 | 任务数 | Worker 总耗时 | 小时 | 单任务中位数 | 引擎耗时合计 | 排队等待合计 |
|---|---:|---:|---:|---:|---:|---:|
| S | 26 | 13006.856 s | 3.613 | 96.176 s | 12885.499 s | 77032.391 s |
| F | 26 | 26434.483 s | 7.343 | 181.824 s | 26309.428 s | 78550.029 s |
| D | 26 | 16909.198 s | 4.697 | 193.277 s | 16772.870 s | 80819.414 s |
| 合计 | 78 | 56350.537 s | 15.653 | — | 55967.796 s | 236401.835 s |

S/F CWF 计算时间分别为 3917.026 s 和 17585.462 s，F/S=4.489×；S/F 的最终 Rwp 在 26/26 个样品完全一致。按完整 Worker 时间合计，F/S=2.032×。因此 4.49× 是 CWF 子流程加速比，不是整个完整精修流程的加速比。

## 2. 40 组 Top-1 同起点对照

40/40 对照使用同一 snapshot SHA，且两候选记录的起始 native weighted SSE 完全相同。R00 Top-1 为 ATOM_UISO（40）；R11 为 ATOM_POSITION（33）或 SAMPLE_SIZE（7）。候选日志保存了前后 weighted SSE 与返回后的候选 Rwp；没有把候选尝试误称为最终 canonical 结果。

- 接受记录：R00 33/40，R11 28/40。
- 配对接受情况：两者接受 25；仅 R00 接受 8；仅 R11 接受 3；均未接受 4。
- 两边 Native solver 均成功的可比较对照：35/40。其余 5 对至少一侧 solver 失败，不纳入成功候选优劣方向统计。
- 在 35 个双成功对照中，R00 候选 Rwp 较低 24 组，R11 较低 5 组，相同 6 组；按同起点 native weighted-SSE 变化，R00 改善更多 24 组、R11 改善更多 5 组、相同 6 组。
- 双成功对照的中位差：`R11-R00 candidate Rwp = 0.031213` 个百分点；`R11 delta-SSE - R00 delta-SSE = 381.521816`。正值表示 R00 在该配对中获得更低候选 Rwp/更大的 SSE 降幅。

这组数据不支持“R11/受限策略当前更好”的结论。`accepted` 是程序现有门禁的结果，不是独立科学有效性判定；Rwp/SSE 也不是物理真实性评分。

## 3. 负 Uiso 最终状态审计

依据现有 2σ 规则，直接 Uiso 候选审计共 S=44、F=44、D=65 条，三组均无 `significant_negative=true` 的目标候选。最终 canonical 摘要中仍可见负 Uiso，结果如下（Å²）：

| 组 | 最终 canonical 负 Uiso 原子数 | >2σ | ≤2σ | σ 不可用 |
|---|---:|---:|---:|---:|
| S | 6 | 0 | 6 | 0 |
| F | 6 | 0 | 6 | 0 |
| D | 13 | 7 | 6 | 0 |

S/F 的 6 个负 Uiso 均在 2σ 内。D 组有 13 个负值，其中 7 个超过 2σ、6 个在 2σ 内；7 个显著负值分布于 PG_0846、PG_0908、PG_1012、PG_1027、PG_1045（两个原子）和 PG_4748。它们在 Final Joint 前的记录已是显著负值，`introduced=false`，故“Final Joint 仅拒绝新引入异常”的规则不会回退这些已存在状态。由此可见该门禁不是全局最终 Uiso 非负/显著性过滤器。

PG_1026 的 S/F Final Joint 尝试将 O1 从 `−0.004183 Å², z=1.151` 推到 `−0.008525 Å², z=2.395`；最终状态为 `rejected_non_regression`，canonical 保留前值（−0.004183 Å²）。审计记录的回退原因是 `OBJECTIVE_REGRESSION / NO_VALID_PROGRESS`，不是 Uiso 专属拒绝原因。因此结果确实回滚，但本案例不能证明是 Uiso 门禁单独触发了回退。

## 4. 16 条调度失败与完整结果摘要不一致

16/16 均有 trial JSON、链接的 summary JSON，以及 `before.gpx`、`attempted.gpx`、`retained_after.gpx` 三个事务证据文件。按真实候选记录拆分：

- 8 条：Native 成功且 candidate accepted，但 scheduler 标记 `REFINEMENT_FAILED`，属于明确状态不一致。
- 7 条：Native 求解成功、候选因 objective/acceptance gate 被拒绝；运行记录完整，候选拒绝不等同于基础设施/精修任务未执行。
- 1 条：原生求解器确实失败，但完整失败记录和事务证据已落盘。

所以应将“任务执行/证据落盘状态”与“候选是否被接受、solver 是否成功”分开统计，而不是把 16 条都记成无结果失败。Runner 总状态另记录 `pipeline_error=KeyError: 'early_instance_id'`；它是汇总/管线错误，不改变以上 16 条逐项结果证据。

## 文件与边界

补充包包含上述新表及原包文件；不包含 XYE、CIF、仪器参数或 GPX 文件。CSV 中的相对路径仅用于指向本地实验根目录中的原始记录，不会把这些源文件复制进压缩包。所有原始实验文件保持未修改。
